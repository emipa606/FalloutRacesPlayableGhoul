﻿using System;
using System.Collections.Generic;
using RimWorld;
using Verse;

namespace GlowingGhoul
{
    public class CompProperties_GlowingGhoul : CompProperties_Glower
    {
        public CompProperties_GlowingGhoul()
        {
            this.compClass = typeof(Comp_GlowingGhoul);
        }

    }
}

